# FVTT-Sta
Adds a new type of dice: the Star Trek: Adventures event Die.  
Comes with 'Dice So Nice!' support.  
Usage: 
```
/r 1dsta
```

